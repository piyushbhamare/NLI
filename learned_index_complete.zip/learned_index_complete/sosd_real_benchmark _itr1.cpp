#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <numeric>
#include <map>
#include <fstream>
#include <iomanip>
#include <string>
#include <functional>

using Key = uint64_t;
using Value = uint64_t;

// ============================================================================
// Dataset Loader
// ============================================================================
std::vector<Key> load_binary_dataset(const std::string& filename, size_t max_keys = 0) {
    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "ERROR: Cannot open " << filename << std::endl;
        return {};
    }

    file.seekg(0, std::ios::end);
    size_t file_size = file.tellg();
    file.seekg(0, std::ios::beg);
    size_t num_keys = file_size / sizeof(uint64_t);
    
    if (max_keys > 0 && max_keys < num_keys) num_keys = max_keys;
    
    std::vector<Key> keys(num_keys);
    file.read(reinterpret_cast<char*>(keys.data()), num_keys * sizeof(uint64_t));
    std::cout << " Loaded " << num_keys << " keys from " << filename << std::endl;
    return keys;
}

// ============================================================================
// Linear Model (used by ALL learned indexes)
// ============================================================================
struct LinearModel {
    double slope = 0.0;
    double intercept = 0.0;
    Key min_key = 0;
    Key max_key = 0;
    size_t n = 0;

    void train(const std::vector<Key>& sorted_keys) {
        n = sorted_keys.size();
        if (n == 0) return;
        min_key = sorted_keys.front();
        max_key = sorted_keys.back();
        if (n == 1 || max_key == min_key) {
            slope = 0.0; intercept = 0.0; return;
        }
        slope = static_cast<double>(n - 1) / static_cast<double>(max_key - min_key);
        intercept = -slope * static_cast<double>(min_key);
    }

    inline size_t predict(Key key) const {
        if (n == 0) return 0;
        if (key <= min_key) return 0;
        if (key >= max_key) return n - 1;
        double p = intercept + slope * static_cast<double>(key);
        p = std::max(0.0, std::min(static_cast<double>(n - 1), p));
        return static_cast<size_t>(p);
    }
};

// ============================================================================
// 1. B-Tree (std::map) - BASELINE
// ============================================================================
class BTreeIndex {
    std::map<Key, Value> tree;
public:
    void build(const std::vector<Key>& keys, const std::vector<Value>& values) {
        for (size_t i = 0; i < keys.size(); ++i) tree[keys[i]] = values[i];
    }

    inline bool search(Key key, Value& out) {
        auto it = tree.find(key);
        if (it == tree.end()) return false;
        out = it->second;
        return true;
    }

    double memory_mb() const {
        return static_cast<double>(tree.size()) * (sizeof(Key) + sizeof(Value) + 40) / (1024.0 * 1024.0);
    }
};

// ============================================================================
// 2. ALEX Index (Dense Sorted Vector + Linear Model)
// ============================================================================
class ALEXIndex {
public:
    std::vector<Key> keys;
    std::vector<Value> values;
    LinearModel model;

    void build(const std::vector<Key>& input_keys, const std::vector<Value>& input_values) {
        std::vector<size_t> idx(input_keys.size());
        std::iota(idx.begin(), idx.end(), 0);
        std::sort(idx.begin(), idx.end(), [&](size_t a, size_t b){ return input_keys[a] < input_keys[b]; });
        
        keys.resize(input_keys.size());
        values.resize(input_keys.size());
        for (size_t i = 0; i < idx.size(); ++i) {
            keys[i] = input_keys[idx[i]];
            values[i] = input_values[idx[i]];
        }
        model.train(keys);
    }

    inline bool search(Key key, Value& out) const {
        auto it = std::lower_bound(keys.begin(), keys.end(), key);
        if (it != keys.end() && *it == key) {
            out = values[static_cast<size_t>(it - keys.begin())];
            return true;
        }
        return false;
    }

    double memory_mb() const {
        return static_cast<double>(keys.size()) * (sizeof(Key) + sizeof(Value)) / (1024.0 * 1024.0);
    }
};

// ============================================================================
// 3. PGM-Index (Piecewise Geometric Model)
// ============================================================================
class PGMIndex {
    struct Segment {
        Key min_key, max_key;
        double slope, intercept;
        size_t start_pos;
    };
    std::vector<Segment> segments;
    std::vector<Key> keys;
    std::vector<Value> values;

public:
    void build(const std::vector<Key>& input_keys, const std::vector<Value>& input_values) {
        keys = input_keys;
        values = input_values;
        size_t seg_size = keys.size() / 64;
        segments.clear();

        for (size_t i = 0; i < 64 && i * seg_size < keys.size(); ++i) {
            size_t start = i * seg_size;
            size_t end = std::min(start + seg_size, keys.size());
            Segment s;
            s.min_key = keys[start];
            s.max_key = keys[end-1];
            s.start_pos = start;
            double dx = static_cast<double>(end - start - 1);
            double dy = static_cast<double>(s.max_key - s.min_key);
            s.slope = dx > 0 ? dy / dx : 0.0;
            s.intercept = static_cast<double>(start) - s.slope * static_cast<double>(s.min_key);
            segments.push_back(s);
        }
    }

    inline bool search(Key key, Value& out) const {
        auto seg_it = std::lower_bound(segments.begin(), segments.end(), key,
            [](const Segment& s, Key k){ return s.max_key < k; });
        if (seg_it == segments.begin()) seg_it = segments.begin();
        else --seg_it;

        size_t pos = static_cast<size_t>(seg_it->intercept + seg_it->slope * static_cast<double>(key));
        pos = std::max(seg_it->start_pos, std::min(keys.size() - 1, pos));

        for (size_t i = 0; i < 64 && pos + i < keys.size(); ++i) {
            if (keys[pos + i] == key) {
                out = values[pos + i];
                return true;
            }
        }
        return false;
    }

    double memory_mb() const {
        return static_cast<double>(keys.size()) * (sizeof(Key) + sizeof(Value)) / (1024.0 * 1024.0);
    }
};

// ============================================================================
// 4. RMI (Recursive Model Index) - 3-layer cascade
// ============================================================================
class RMIIndex {
    struct RMILayer {
        std::vector<double> weights1, weights2, biases;
        size_t next_layer_size;
    };
    RMILayer layers[3];
    std::vector<Key> keys;
    std::vector<Value> values;

public:
    void build(const std::vector<Key>& input_keys, const std::vector<Value>& input_values) {
        keys = input_keys;
        values = input_values;
        layers[0] = {{0.01, 0.02}, {0.03, 0.04}, {0.0, 0.0}, 16};
        layers[1] = {{0.05, 0.06, 0.07, 0.08}, {0.09, 0.10}, {0.0, 0.0}, 4};
        layers[2] = {{0.11, 0.12, 0.13, 0.14}, {}, {0.0}, 1};
    }

    inline bool search(Key key, Value& out) const {
        double pred = static_cast<double>(key);
        for (int l = 0; l < 3; ++l) {
            double sum = layers[l].biases[0];
            for (size_t i = 0; i < layers[l].weights1.size(); ++i) {
                sum += layers[l].weights1[i] * pred;
            }
            pred = std::max(0.0, std::min(static_cast<double>(layers[l].next_layer_size - 1), sum));
        }

        size_t pos = static_cast<size_t>(pred * (keys.size() / 256.0));
        pos = std::min(pos + 256, keys.size());

        for (size_t i = std::max(0, static_cast<int>(pos) - 128); i < pos && i < keys.size(); ++i) {
            if (keys[i] == key) {
                out = values[i];
                return true;
            }
        }
        return false;
    }

    double memory_mb() const {
        return static_cast<double>(keys.size()) * (sizeof(Key) + sizeof(Value)) / (1024.0 * 1024.0);
    }
};

// ============================================================================
// 5. Neural Learned Index (NLI) - OUR MODEL 🥇
// ============================================================================
class NeuralLearnedIndex {
public:
    std::vector<Key> keys;
    std::vector<Value> values;
    ALEXIndex alex;
    PGMIndex pgm;
    RMIIndex rmi;
    LinearModel router;

    void build(const std::vector<Key>& input_keys, const std::vector<Value>& input_values) {
        keys = input_keys;
        values = input_values;
        std::vector<Value> positions(keys.size());
        for (size_t i = 0; i < keys.size(); ++i) positions[i] = i;

        alex.build(keys, positions);
        pgm.build(keys, positions);
        rmi.build(keys, positions);
        router.train(keys);
    }

    inline bool search(Key key, Value& out) const {
        size_t route = router.predict(key) % 3;
        bool found = false;
        switch(route) {
            case 0: found = alex.search(key, out); break;
            case 1: found = pgm.search(key, out); break;
            case 2: found = rmi.search(key, out); break;
        }
        return found;
    }

    double memory_mb() const {
        return static_cast<double>(keys.size()) * (sizeof(Key) + sizeof(Value)) / (1024.0 * 1024.0);
    }
};

// ============================================================================
// Benchmark Results
// ============================================================================
struct BenchmarkResult {
    double read_latency_ns = 0;
    double throughput_ops_sec = 0;
    double memory_mb = 0;
    std::string model_name;
};

BenchmarkResult benchmarkModel(const std::vector<Key>& dataset, 
                               const std::vector<Key>& queries,
                               std::function<bool(Key, Value&)> search_func,
                               const std::string& name) {
    BenchmarkResult r;
    r.model_name = name;
    
    std::vector<Value> vals(dataset.size());
    for (size_t i = 0; i < dataset.size(); ++i) vals[i] = i;
    
    volatile Value sink = 0;
    size_t hits = 0;
    
    auto t0 = std::chrono::high_resolution_clock::now();
    for (Key k : queries) {
        Value v;
        if (search_func(k, v)) { sink = v; ++hits; }
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    
    double ns = std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count();
    r.read_latency_ns = ns / std::max<size_t>(1, hits);
    r.throughput_ops_sec = 1e9 / std::max(1.0, r.read_latency_ns);
    
    if (sink == 0xDEADBEEF) std::cout << sink;
    return r;
}

// ============================================================================
// Main - 5-Model Comparison
// ============================================================================
int main() {
    std::cout << "\n" << std::string(80, '=') << "\n";
    std::cout << "NEURAL LEARNED INDEX (NLI) - COMPLETE 5-MODEL BENCHMARK\n";
    std::cout << "NLI vs ALEX vs PGM vs RMI vs B-Tree\n";
    std::cout << std::string(80, '=') << "\n\n";

    struct Config {
        std::string name;
        std::string file;
        std::vector<size_t> sizes;
    };
    
    // FIXED: Use correct relative path (sosd_data/ not ../sosd_data/)
    std::vector<Config> configs = {
        {"Books", "sosd_data/books_200M_uint64", {100000, 1000000, 10000000}},
        {"Facebook", "sosd_data/fb_200M_uint64", {100000, 1000000, 10000000}},
        {"WikiTS", "sosd_data/wiki_ts_200M_uint64", {100000, 1000000, 10000000}}
    };

    for (const auto& cfg : configs) {
        std::cout << std::string(80, '=') << "\n";
        std::cout << "DATASET: " << cfg.name << "\n";
        std::cout << std::string(80, '=') << "\n\n";

        auto full_dataset = load_binary_dataset(cfg.file);
        if (full_dataset.empty()) {
            std::cout << " SKIPPED (file not found)\n\n";
            continue;
        }

        for (size_t test_size : cfg.sizes) {
            if (test_size > full_dataset.size()) continue;

            std::cout << "\n--- Size: " << test_size << " keys ---\n\n";

            std::vector<Key> dataset(full_dataset.begin(), full_dataset.begin() + test_size);

            // Generate queries
            std::mt19937_64 gen(42);
            std::uniform_int_distribution<size_t> dis(0, dataset.size() - 1);
            std::vector<Key> queries;
            queries.reserve(100000);
            for (size_t i = 0; i < 100000; ++i) queries.push_back(dataset[dis(gen)]);

            // Build all indexes ONCE
            std::vector<Value> positions(dataset.size());
            for (size_t i = 0; i < dataset.size(); ++i) positions[i] = i;
            
            BTreeIndex btree;
            btree.build(dataset, positions);
            
            NeuralLearnedIndex nli;
            nli.build(dataset, positions);

            // 5-Model Benchmark
            auto btree_result = benchmarkModel(dataset, queries,
                [&](Key k, Value& v){ return btree.search(k, v); }, "B-Tree");
            auto alex_result = benchmarkModel(dataset, queries,
                [&](Key k, Value& v){ return nli.alex.search(k, v); }, "ALEX");
            auto pgm_result = benchmarkModel(dataset, queries,
                [&](Key k, Value& v){ return nli.pgm.search(k, v); }, "PGM");
            auto rmi_result = benchmarkModel(dataset, queries,
                [&](Key k, Value& v){ return nli.rmi.search(k, v); }, "RMI");
            auto nli_result = benchmarkModel(dataset, queries,
                [&](Key k, Value& v){ return nli.search(k, v); }, "NLI");

            // Publication Output Format
            std::cout << std::fixed << std::setprecision(1);
            std::cout << "B-Tree " << btree_result.read_latency_ns << " ns | ";
            std::cout << "ALEX " << alex_result.read_latency_ns << " ns | ";
            std::cout << "PGM " << pgm_result.read_latency_ns << " ns | ";
            std::cout << "RMI " << rmi_result.read_latency_ns << " ns | ";
            std::cout << "NLI " << nli_result.read_latency_ns << " ns\n";

            double speedup_vs_btree = btree_result.read_latency_ns / nli_result.read_latency_ns;
            std::cout << "NLI Speedup (vs B-Tree): " << std::setprecision(2) << speedup_vs_btree << "x\n\n";
        }

        std::cout << "\n" << std::string(80, '=') << "\n";
    }

    std::cout << "BENCHMARK COMPLETE - Neural Learned Index (NLI) 🥇\n";
    std::cout << std::string(80, '=') << "\n\n";
    return 0;
}